/**
 * Each attribute is defined in a file in js/designerModels.
 * Each attribute is a method which will draw the model on the context.
 */
var DesignerModels = {
	// TODO find a better way to draw that (maybe with SVG files ? How to draw them on canvas) ?
};