alert(Element.prototype.mozRequestPointerLock);

var vendors = ['ms', 'moz', 'webkit', 'o'];
