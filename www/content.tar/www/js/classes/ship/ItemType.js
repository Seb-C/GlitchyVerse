var ItemType = function(definition) {
	this.id       = definition.id;
	this.name     = definition.name;
	this.maxState = definition.max_state;
	this.groups   = definition.groups;
};
